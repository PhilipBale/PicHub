angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
    // Form data for the login modal
    $scope.loginData = {};

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/login.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });

    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
            $scope.modal.hide();
        },

        // Open the login modal
        $scope.login = function() {
            $scope.modal.show();
        };

    // Perform the login action when the user submits the login form
    $scope.doLogin = function() {
        console.log('Doing login', $scope.loginData);

        // Simulate a login delay. Remove this and replace with your login
        // code if using a login system
        $timeout(function() {
            $scope.closeLogin();
        }, 1000);
    };
})

.controller('HomeCtrl', function($scope, $ionicModal, $timeout, $http) {
    $scope.countdownTime = 0;
    $scope.onTimeout = function() {
        $scope.countdownTime--;
        if ($scope.countdownTime > 0) {
            mytimeout = $timeout($scope.onTimeout, 1000);
        } else {
            $scope.modal.hide();
        }
    }
    var mytimeout = 0;

    $http.jsonp('http://devserver.chandlermatz.com/getData.php?callback=JSON_CALLBACK').success(function(data) {
        $scope.items = data;
    });

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/image-view.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });

    // Triggered in the login modal to close it
    $scope.closeModalImage = function() {
            $timeout.cancel(mytimeout);
            $scope.modal.hide();
        },

        // Open the login modal
        $scope.showModalImage = function() {
            $scope.modal.show();
        };

    $scope.voteYes = function(id) {

        $http.get('http://devserver.chandlermatz.com/vote.php?direction=1&id=' + id).finally(function() {

            $scope.updateItems();
        });
    };

    $scope.voteNo = function(id) {
        $http.get('http://devserver.chandlermatz.com/vote.php?direction=0&id=' + id).finally(function() {

            $scope.updateItems();
        });
    };

    $scope.showImage = function(item) {
        $scope.imageSrc = item.image_name.replace('.jpg', '');
        $scope.countdownTime = item.time_limit;
        $scope.showModalImage();
        mytimeout = $timeout($scope.onTimeout, 1000);
    };

    $scope.capturePhoto = function() {
        if (navigator.camera != null) {
            navigator.camera.getPicture(uploadPhoto, onFailedPhoto, {
                sourceType: 1,
                quality: 50,
                encodingType: 0,
                saveToPhotoAlbum: false,
                targetWidth: 640,
                targetHeight: 960,
                correctOrientation: true
            });
        } else {
            alert("Camera not supported!");
        }
    }

    $scope.updateItems = function() {
        $http.jsonp('http://devserver.chandlermatz.com/getData.php?callback=JSON_CALLBACK').success(function(data) {
            $scope.items = data;
        });
    }

    function uploadPhoto(data) {
        $scope.cameraSrc = "data:image/jpeg;base64," + data;

        /*$.post( "upload.php", {data: imageData}, function(data) {
			alert("Image uploaded!");
		}); */
        var options = new FileUploadOptions();
        options.fileKey = "file";
        options.fileName = data.substr(data.lastIndexOf('/') + 1);
        options.mimeType = "image/jpeg";
        options.chunkedMode = false;
        options.headers = {
            Connection: "close"
        }

        var params = new Object();
        params.fullPath = data;
        params.name = options.fileName;
        params.imageName = params.name;
        params.userId = 2;
        params.caption = "test " + params.name;
        params.timeLimit = Math.floor((Math.random() * 10) + 1);

        options.params = params;

        var ft = new FileTransfer();
        ft.upload(data, "http://devserver.chandlermatz.com/upload.php", win, fail, options);
    }

    function win(r) {
		alert("Image succesfully posted");
        /*alert("Code = " + r.responseCode);
        alert("Response = " + r.response);
        alert("Sent = " + r.bytesSent);*/
    }

    function fail(error) {
        alert("An error has occurred: Code = " + error.code);
    }

    function onFailedPhoto(data) {
        alert(data);
    }

}).directive('imageonload', function() {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            element.bind('load', function() {
                //alert("loaded: " + attrs.src);
            });
        }
    };
}).controller('ImgCaptCtrl', function($scope, $ionicModal) {
    $scope.countdownTime = 0;
    $scope.simulatePost = function(caption) {
        if (caption != null) {
            alert(caption);
        }
    };

});